public class Probando {
    public static void main(String[] args){
        System.out.println("Funciona correctamente");
    }
}
